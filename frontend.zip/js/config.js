// ============================================================
// KONFIGURASI FRONTEND
// Satu-satunya nilai yang diisi manual: URL Web App GAS (/exec).
// Client ID Google diambil otomatis dari backend (auth.config).
// ============================================================
window.APP_CONFIG = {
  GAS_URL: 'https://script.google.com/macros/s/GANTI_DENGAN_ID_DEPLOYMENT/exec'
};
